|    TAG    | COUNT |    AUTHOR     | COUNT | DIRECTORY  | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|---------------|-------|------------|-------|----------|-------|------|-------|
| cve       |  3225 | dhiyaneshdk   |  1866 | http       |  8825 | info     |  4118 | file |   435 |
| panel     |  1327 | daffainfo     |   868 | cloud      |   657 | high     |  2423 | dns  |    26 |
| xss       |  1246 | dwisiswant0   |   806 | file       |   435 | medium   |  2339 |      |       |
| wordpress |  1168 | princechaddha |   806 | dast       |   255 | critical |  1391 |      |       |
| exposure  |  1094 | ritikchaddha  |   633 | workflows  |   202 | low      |   318 |      |       |
| wp-plugin |  1023 | pussycat0x    |   519 | code       |   174 | unknown  |    54 |      |       |
| osint     |   810 | pikpikcu      |   352 | network    |   141 |          |       |      |       |
| tech      |   782 | pdteam        |   308 | javascript |    71 |          |       |      |       |
| lfi       |   772 | pdresearch    |   251 | ssl        |    38 |          |       |      |       |
| rce       |   770 | ricardomaia   |   249 | dns        |    23 |          |       |      |       |
