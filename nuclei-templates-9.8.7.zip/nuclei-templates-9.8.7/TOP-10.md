|    TAG    | COUNT |    AUTHOR     | COUNT | DIRECTORY  | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|---------------|-------|------------|-------|----------|-------|------|-------|
| cve       |  2474 | dhiyaneshdk   |  1277 | http       |  7417 | info     |  3657 | file |   337 |
| panel     |  1133 | daffainfo     |   864 | file       |   337 | high     |  1703 | dns  |    25 |
| wordpress |   973 | dwisiswant0   |   803 | workflows  |   191 | medium   |  1517 |      |       |
| exposure  |   908 | pikpikcu      |   353 | network    |   138 | critical |  1029 |      |       |
| xss       |   904 | pussycat0x    |   353 | cloud      |    98 | low      |   265 |      |       |
| wp-plugin |   844 | ritikchaddha  |   336 | code       |    81 | unknown  |    39 |      |       |
| osint     |   804 | pdteam        |   297 | javascript |    56 |          |       |      |       |
| tech      |   674 | princechaddha |   268 | ssl        |    29 |          |       |      |       |
| lfi       |   654 | ricardomaia   |   232 | dns        |    22 |          |       |      |       |
| misconfig |   606 | geeknik       |   230 | dast       |    21 |          |       |      |       |
